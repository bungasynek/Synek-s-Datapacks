execute as @s if predicate rusticmatcha_item:mainhand/bell_pepper_purple run function rusticmatcha_item:mainhand/bell_pepper_purple
execute as @s if predicate rusticmatcha_item:offhand/bell_pepper_purple run function rusticmatcha_item:offhand/bell_pepper_purple
advancement revoke @s only rusticmatcha_item:trigger/bell_pepper_purple
