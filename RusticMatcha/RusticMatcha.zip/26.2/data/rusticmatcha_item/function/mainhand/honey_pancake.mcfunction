item modify entity @s weapon.mainhand rusticmatcha_item:modify/honey_pancake
